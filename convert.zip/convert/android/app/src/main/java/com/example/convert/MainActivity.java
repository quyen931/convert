package com.example.convert;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
